package com.example.memwidget;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.widget.RemoteViews;

import java.util.Locale;

/**
 * Монохромный белый виджет в стиле One UI: две «таблетки» —
 * хранилище и ОЗУ. Рисуется в Bitmap под текущий размер виджета,
 * поэтому растягивается по ширине (и высоте) без искажений.
 */
public class MemoryWidget extends AppWidgetProvider {

    static final String ACTION_REFRESH = "com.example.memwidget.REFRESH";
    private static final Locale RU = new Locale("ru", "RU");

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) update(c, m, id);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        update(c, m, id);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (ACTION_REFRESH.equals(i.getAction())) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, MemoryWidget.class));
            onUpdate(c, m, ids);
        }
    }

    private static void update(Context c, AppWidgetManager m, int id) {
        Bundle o = m.getAppWidgetOptions(id);
        boolean land = c.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        int wDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH
                : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int hDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT
                : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (wDp <= 0) wDp = 250;
        if (hDp <= 0) hDp = 110;

        float d = c.getResources().getDisplayMetrics().density;
        float w = wDp * d, h = hDp * d;
        // не раздуваем Bitmap сверх разумного
        float maxPx = 2_500_000f;
        if (w * h > maxPx) {
            float k = (float) Math.sqrt(maxPx / (w * h));
            w *= k;
            h *= k;
            d *= k;
        }

        // --- Хранилище: десятичные ГБ, ёмкость округляется до «маркетинговой» (128/256/512...)
        StatFs s = new StatFs(Environment.getDataDirectory().getPath());
        double totalGb = s.getTotalBytes() / 1e9;
        double cap = 1;
        while (cap < totalGb) cap *= 2;
        double usedStor = cap - s.getAvailableBytes() / 1e9;
        if (usedStor < 0) usedStor = 0;

        // --- ОЗУ: ГиБ, объём округляется вверх до целого
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        double gib = 1024.0 * 1024 * 1024;
        double totalRam = Math.ceil(mi.totalMem / gib);
        double usedRam = (mi.totalMem - mi.availMem) / gib;

        Bitmap bmp = render((int) w, (int) h, d,
                (float) (usedStor / cap), fmt(usedStor) + " ГБ / " + fmt(cap) + " ГБ", false,
                (float) (usedRam / totalRam), fmt(usedRam) + " ГБ / " + fmt(totalRam) + " ГБ");

        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
        rv.setImageViewBitmap(R.id.img, bmp);
        Intent refresh = new Intent(c, MemoryWidget.class).setAction(ACTION_REFRESH);
        rv.setOnClickPendingIntent(R.id.root, PendingIntent.getBroadcast(
                c, 0, refresh, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        m.updateAppWidget(id, rv);
    }

    private static String fmt(double v) {
        double r = Math.round(v * 10) / 10.0;
        if (r == Math.floor(r)) return String.valueOf((long) r);
        return String.format(RU, "%.1f", r);
    }

    private static Bitmap render(int w, int h, float d,
                                 float f1, String t1, boolean unused,
                                 float f2, String t2) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float rowH = Math.min(56 * d, (h - 10 * d) / 2f);
        float gap = Math.min(10 * d, h * 0.1f);
        float top = (h - (2 * rowH + gap)) / 2f;
        drawRow(cv, w, top, rowH, f1, t1, true);
        drawRow(cv, w, top + rowH + gap, rowH, f2, t2, false);
        return b;
    }

    private static void drawRow(Canvas cv, float w, float y, float rowH,
                                float frac, String text, boolean storage) {
        frac = Math.max(0f, Math.min(1f, frac));
        float r = rowH / 2f;
        float cx = r, cy = y + r;
        float fillW = rowH + (w - rowH) * frac;

        Path track = new Path();
        track.addRoundRect(new RectF(0, y, w, y + rowH), r, r, Path.Direction.CW);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x4DFFFFFF);          // полупрозрачная белая подложка
        cv.drawPath(track, p);

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tp.setTextSize(rowH * 0.34f);
        tp.setTextAlign(Paint.Align.RIGHT);
        float tx = w - rowH * 0.55f;
        float ty = cy - (tp.ascent() + tp.descent()) / 2f;

        // белый текст на подложке
        tp.setColor(0xFFFFFFFF);
        cv.drawText(text, tx, ty, tp);

        // заливка + тёмный текст поверх неё (там, где текст заходит на белое)
        cv.save();
        cv.clipPath(track);
        cv.clipRect(0, y, fillW, y + rowH);
        p.setColor(0xFFFFFFFF);
        cv.drawRect(0, y, fillW, y + rowH, p);
        tp.setColor(0xFF111111);
        cv.drawText(text, tx, ty, tp);
        cv.restore();

        // иконка — тёмная на белой «шапке»
        p.setColor(0xFF111111);
        float ir = rowH * 0.22f;
        if (storage) {
            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(ir * 0.55f);
            ring.setColor(0xFF111111);
            cv.drawArc(new RectF(cx - ir, cy - ir, cx + ir, cy + ir), 35, 290, false, ring);
            cv.drawCircle(cx, cy, ir * 0.28f, p);
        } else {
            float bw = ir * 0.95f, bh = ir * 0.7f;
            cv.drawRoundRect(new RectF(cx - bw, cy - bh, cx + bw, cy + bh), ir * 0.3f, ir * 0.3f, p);
            float pw = ir * 0.22f, ph = ir * 0.3f;
            for (int i = 0; i < 4; i++) {
                float px = cx - bw + ir * 0.18f + i * (bw * 2 - ir * 0.36f - pw) / 3f;
                cv.drawRoundRect(new RectF(px, cy - bh - ph - ir * 0.12f, px + pw, cy - bh - ir * 0.12f), pw / 2, pw / 2, p);
                cv.drawRoundRect(new RectF(px, cy + bh + ir * 0.12f, px + pw, cy + bh + ph + ir * 0.12f), pw / 2, pw / 2, p);
            }
        }
    }
}
