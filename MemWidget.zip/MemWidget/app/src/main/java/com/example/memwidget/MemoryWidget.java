package com.example.memwidget;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.widget.RemoteViews;

import java.util.Locale;

/**
 * Монохромный белый виджет в одну строку: слева хранилище, справа ОЗУ.
 * Каждая половина — отдельная картинка со своим нажатием.
 */
public class MemoryWidget extends AppWidgetProvider {

    static final String ACTION_REFRESH = "com.example.memwidget.REFRESH";
    static final String PREFS = "widget_prefs";
    private static final Locale RU = new Locale("ru", "RU");
    private static final float GAP_DP = 8f; // 4dp + 4dp отступы в layout

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) update(c, m, id);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        update(c, m, id);
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        for (int id : ids) e.remove("s_" + id).remove("r_" + id);
        e.apply();
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (ACTION_REFRESH.equals(i.getAction())) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, MemoryWidget.class));
            onUpdate(c, m, ids);
        }
    }

    static void update(Context c, AppWidgetManager m, int id) {
        Bundle o = m.getAppWidgetOptions(id);
        boolean land = c.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        int wDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH
                : AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        int hDp = o.getInt(land ? AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT
                : AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (wDp <= 0) wDp = 320;
        if (hDp <= 0) hDp = 56;

        float d = c.getResources().getDisplayMetrics().density;
        float w = (wDp - GAP_DP) / 2f * d;   // ширина одной половины
        float h = hDp * d;
        float maxPx = 1_500_000f;
        if (w * h > maxPx) {
            float k = (float) Math.sqrt(maxPx / (w * h));
            w *= k;
            h *= k;
            d *= k;
        }

        // Хранилище: десятичные ГБ, ёмкость округляется до 128/256/512...
        StatFs s = new StatFs(Environment.getDataDirectory().getPath());
        double totalGb = s.getTotalBytes() / 1e9;
        double cap = 1;
        while (cap < totalGb) cap *= 2;
        double usedStor = cap - s.getAvailableBytes() / 1e9;
        if (usedStor < 0) usedStor = 0;

        // ОЗУ: ГиБ, объём округляется вверх до целого
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        double gib = 1024.0 * 1024 * 1024;
        double totalRam = Math.ceil(mi.totalMem / gib);
        double usedRam = (mi.totalMem - mi.availMem) / gib;

        Bitmap b1 = render((int) w, (int) h, d, (float) (usedStor / cap),
                fmt(usedStor) + " / " + fmt(cap) + " ГБ", true);
        Bitmap b2 = render((int) w, (int) h, d, (float) (usedRam / totalRam),
                fmt(usedRam) + " / " + fmt(totalRam) + " ГБ", false);

        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget);
        rv.setImageViewBitmap(R.id.img_storage, b1);
        rv.setImageViewBitmap(R.id.img_ram, b2);

        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        rv.setOnClickPendingIntent(R.id.img_storage,
                clickIntent(c, id, 0, sp.getString("s_" + id, null)));
        rv.setOnClickPendingIntent(R.id.img_ram,
                clickIntent(c, id, 1, sp.getString("r_" + id, null)));
        m.updateAppWidget(id, rv);
    }

    /** Открыть выбранное приложение, а если не выбрано — обновить виджет. */
    private static PendingIntent clickIntent(Context c, int id, int side, String pkg) {
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent launch = null;
        if (pkg != null) launch = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return PendingIntent.getActivity(c, id * 2 + side, launch, flags);
        }
        Intent refresh = new Intent(c, MemoryWidget.class).setAction(ACTION_REFRESH);
        return PendingIntent.getBroadcast(c, 1_000_000 + id * 2 + side, refresh, flags);
    }

    private static String fmt(double v) {
        double r = Math.round(v * 10) / 10.0;
        if (r == Math.floor(r)) return String.valueOf((long) r);
        return String.format(RU, "%.1f", r);
    }

    private static Bitmap render(int w, int h, float d, float frac, String text, boolean storage) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float barH = Math.min(30 * d, h);
        float y = (h - barH) / 2f;
        drawBar(cv, w, y, barH, frac, text, storage);
        return b;
    }

    private static void drawBar(Canvas cv, float w, float y, float barH,
                                float frac, String text, boolean storage) {
        frac = Math.max(0f, Math.min(1f, frac));
        float r = barH / 2f;
        float cx = r, cy = y + r;
        float fillW = barH + (w - barH) * frac;

        Path track = new Path();
        track.addRoundRect(new RectF(0, y, w, y + barH), r, r, Path.Direction.CW);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x4DFFFFFF);          // остаток — полупрозрачный белый
        cv.drawPath(track, p);

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tp.setTextSize(barH * 0.40f);
        tp.setTextAlign(Paint.Align.RIGHT);
        float tx = w - barH * 0.5f;
        float ty = cy - (tp.ascent() + tp.descent()) / 2f;

        tp.setColor(0xFFFFFFFF);         // белый текст на подложке
        cv.drawText(text, tx, ty, tp);

        cv.save();                       // заполненная часть — сплошной белый, текст на ней тёмный
        cv.clipPath(track);
        cv.clipRect(0, y, fillW, y + barH);
        p.setColor(0xFFFFFFFF);
        cv.drawRect(0, y, fillW, y + barH, p);
        tp.setColor(0xFF111111);
        cv.drawText(text, tx, ty, tp);
        cv.restore();

        p.setColor(0xFF111111);          // иконка на белой «шапке»
        float ir = barH * 0.22f;
        if (storage) {
            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(ir * 0.55f);
            ring.setColor(0xFF111111);
            cv.drawArc(new RectF(cx - ir, cy - ir, cx + ir, cy + ir), 35, 290, false, ring);
            cv.drawCircle(cx, cy, ir * 0.28f, p);
        } else {
            float bw = ir * 0.95f, bh = ir * 0.7f;
            cv.drawRoundRect(new RectF(cx - bw, cy - bh, cx + bw, cy + bh), ir * 0.3f, ir * 0.3f, p);
            float pw = ir * 0.22f, ph = ir * 0.3f;
            for (int i = 0; i < 4; i++) {
                float px = cx - bw + ir * 0.18f + i * (bw * 2 - ir * 0.36f - pw) / 3f;
                cv.drawRoundRect(new RectF(px, cy - bh - ph - ir * 0.12f, px + pw, cy - bh - ir * 0.12f), pw / 2, pw / 2, p);
                cv.drawRoundRect(new RectF(px, cy + bh + ir * 0.12f, px + pw, cy + bh + ph + ir * 0.12f), pw / 2, pw / 2, p);
            }
        }
    }
}
