package com.example.memwidget;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Экран выбора: какое приложение открывать по нажатию на «Память» и на «ОЗУ». */
public class ConfigActivity extends Activity {

    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private SharedPreferences sp;
    private Button bStorage, bRam;
    private final List<String[]> apps = new ArrayList<>(); // {название, пакет}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        Bundle ex = getIntent().getExtras();
        if (ex != null) {
            widgetId = ex.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
        }
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        sp = getSharedPreferences(MemoryWidget.PREFS, MODE_PRIVATE);
        loadApps();

        float d = getResources().getDisplayMetrics().density;
        int p = (int) (24 * d);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, (int) (72 * d), p, p);

        TextView title = new TextView(this);
        title.setText("Что открывать по нажатию на полоску");
        title.setTextSize(18);
        root.addView(title);

        bStorage = addButton(root, d, v -> pick(true));
        bRam = addButton(root, d, v -> pick(false));
        Button done = addButton(root, d, v -> finishOk());
        done.setText("Готово");

        refreshButtons();
        setContentView(root);
    }

    private Button addButton(LinearLayout root, float d, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setAllCaps(false);
        btn.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (16 * d);
        root.addView(btn, lp);
        return btn;
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            apps.add(new String[]{String.valueOf(ri.loadLabel(pm)), pkg});
        }
        Collections.sort(apps, (x, y) -> x[0].compareToIgnoreCase(y[0]));
    }

    private String labelFor(String pkg) {
        if (pkg == null) return "обновить виджет";
        for (String[] a : apps) if (a[1].equals(pkg)) return a[0];
        return pkg;
    }

    private void refreshButtons() {
        bStorage.setText("Память: " + labelFor(sp.getString("s_" + widgetId, null)));
        bRam.setText("ОЗУ: " + labelFor(sp.getString("r_" + widgetId, null)));
    }

    private void pick(final boolean storage) {
        String[] names = new String[apps.size() + 1];
        names[0] = "Обновить виджет (по умолчанию)";
        for (int i = 0; i < apps.size(); i++) names[i + 1] = apps.get(i)[0];
        new AlertDialog.Builder(this)
                .setTitle(storage ? "Полоска «Память»" : "Полоска «ОЗУ»")
                .setItems(names, (dlg, which) -> {
                    String key = (storage ? "s_" : "r_") + widgetId;
                    SharedPreferences.Editor e = sp.edit();
                    if (which == 0) e.remove(key);
                    else e.putString(key, apps.get(which - 1)[1]);
                    e.apply();
                    refreshButtons();
                })
                .show();
    }

    private void finishOk() {
        MemoryWidget.update(this, AppWidgetManager.getInstance(this), widgetId);
        Intent r = new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        setResult(RESULT_OK, r);
        finish();
    }
}
